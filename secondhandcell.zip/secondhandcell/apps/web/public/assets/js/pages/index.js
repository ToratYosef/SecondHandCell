import { firebaseApp } from "/assets/js/firebase-app.js";
import { getAuth, signOut, onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signInWithEmailAndPassword, createUserWithEmailAndPassword, updateProfile, sendPasswordResetEmail, signInWithCustomToken } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { getFirestore, collection, addDoc, doc, onSnapshot, query, orderBy, serverTimestamp, updateDoc, setDoc, getDocs, runTransaction, FieldValue } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
import { setLogLevel } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

setLogLevel('debug');

// Use global variables provided by the platform
const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';

const initialAuthToken = typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;

// Initialize Firebase with the provided config
const app = firebaseApp;
const auth = getAuth(app);
const db = getFirestore(app);

// --- Firebase Click Tracker Function ---
const trackButtonClick = async (buttonName) => {
const cleanedButtonName = buttonName.replace(/\s/g, '_').replace(/'/g, '');
const buttonDocRef = doc(db, "button_clicks", cleanedButtonName);
const userId = auth.currentUser?.uid || getOrCreateGuestId();

try {
await runTransaction(db, async (transaction) => {
const buttonDoc = await transaction.get(buttonDocRef);
if (!buttonDoc.exists()) {
transaction.set(buttonDocRef, {
count: 1,
buttonName: buttonName,
history: [{ timestamp: serverTimestamp(), userId: userId }],
lastClicked: serverTimestamp()
});
} else {
const data = buttonDoc.data();
const updatedHistory = [...data.history, { timestamp: serverTimestamp(), userId: userId }];
transaction.update(buttonDocRef, {
count: (data.count || 0) + 1, // Use increment only if supported, fallback to manual if not.
// The line above is a simplified replacement for FieldValue.increment(1) if Firebase version is older.
// Assuming FieldValue is imported correctly as per the header:
// count: FieldValue.increment(1),
history: updatedHistory,
lastClicked: serverTimestamp()
});
}
});
console.log(`Click on '${buttonName}' successfully tracked and updated.`);
} catch (error) {
console.error("Transaction failed: ", error);
}
};
// ----------------------------------------

document.addEventListener('DOMContentLoaded', function() {
// Initial sign-in with custom token or anonymously
onAuthStateChanged(auth, async (user) => {
if (initialAuthToken && !user) {
try {
await signInWithCustomToken(auth, initialAuthToken);
console.log("Signed in with custom token.");
} catch (error) {
console.error("Custom token sign-in failed:", error);
try { await signInAnonymously(auth); } catch (e) { console.error("Anonymous sign-in failed:", e); }
}
} else if (!user) {
try { await signInAnonymously(auth); } catch (e) { console.error("Anonymous sign-in failed:", e); }
}
});

function loadImageWithFallback(imgElement) {
const baseSrc = imgElement.dataset.baseSrc;
if (!baseSrc) return;
const extensions = ['.webp','.svg', '.avif', '.png', '.jpeg', '.jpg', '.svg'];
let current = 0;
function tryLoad() {
if (current >= extensions.length) {
if (imgElement.id.includes('_cat_img')) { imgElement.src = `https://placehold.co/150x150/e0e7ff/4338ca?text=Category`; }
else { imgElement.src = `https://placehold.co/200x200/f0f4ff/6366f1?text=No+Image`; }
imgElement.alt = "Image not available";
return;
}
const testSrc = baseSrc + extensions[current];
const img = new Image();
img.onload = () => { imgElement.src = testSrc; };
img.onerror = () => { current++; tryLoad(); };
img.src = testSrc;
}
tryLoad();
}
document.querySelectorAll('img[data-base-src]').forEach(loadImageWithFallback);

const modals = document.querySelectorAll('.modal');
const openModal = (modalId) => document.getElementById(modalId)?.classList.add('is-visible');
const closeModal = (modal) => modal.classList.remove('is-visible');

document.getElementById('loginNavBtn').addEventListener('click', (e) => { e.preventDefault(); openModal('loginModal'); });
document.getElementById('aboutUsLink').addEventListener('click', (e) => { e.preventDefault(); openModal('aboutUsModal'); });

modals.forEach(modal => {
modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(modal); });
modal.querySelector('.close-modal-btn')?.addEventListener('click', () => closeModal(modal));
});

document.getElementById('heroOfferBtn').addEventListener('click', () => trackButtonClick('Hero_Get_Instant_Offer'));
document.getElementById('finalOfferBtn').addEventListener('click', () => trackButtonClick('Final_Sell_Device_Now'));

document.querySelectorAll('.feature-card h3').forEach(card => {
card.addEventListener('click', () => {
trackButtonClick(`Feature_Card_${card.textContent.trim()}`);
});
});

document.querySelectorAll('.homepage-card-link').forEach(link => {
link.addEventListener('click', (e) => {
const deviceName = e.currentTarget.querySelector('h3').textContent;
trackButtonClick(`Popular_Device_Get_Offer_${deviceName}`);
});
});

// NEW: Click handlers for external review links
document.querySelectorAll('.review-link-card').forEach(link => {
link.addEventListener('click', () => {
const platformName = link.querySelector('h3').textContent;
trackButtonClick(`External_Review_Click_${platformName.replace(/\s/g, '_')}`);
});
});

const footerEmailSignupForm = document.getElementById('footerEmailSignupForm');
const footerSignupMessage = document.getElementById('footerSignupMessage');
footerEmailSignupForm.addEventListener('submit', async (e) => {
e.preventDefault();
const email = document.getElementById('footerPromoEmail').value;
footerSignupMessage.textContent = 'Submitting...';
footerSignupMessage.className = 'mt-3 text-sm text-center text-blue-300';

try {
await addDoc(collection(db, "signed_up_emails"), {
email: email,
timestamp: new Date()
});
footerSignupMessage.textContent = 'Success! Thanks for signing up.';
footerSignupMessage.className = 'mt-3 text-sm text-center text-green-300';
footerEmailSignupForm.reset();
trackButtonClick('Footer_Email_Signup');
} catch (error) {
console.error("Error adding document: ", error);
footerSignupMessage.textContent = 'Error: Could not sign up.';
footerSignupMessage.className = 'mt-3 text-sm text-center text-red-300';
}
});

const authStatusContainer = document.getElementById('authStatusContainer');
const userMonogram = document.getElementById('userMonogram');
const authDropdown = document.getElementById('authDropdown');
const logoutBtn = document.getElementById('logoutBtn');
const loginTabBtn = document.getElementById('loginTabBtn');
const signupTabBtn = document.getElementById('signupTabBtn');
const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');
const forgotPasswordForm = document.getElementById('forgotPasswordForm');
const authMessage = document.getElementById('authMessage');

const showTab = (tabName) => {
authMessage.classList.add('hidden');
[loginForm, signupForm, forgotPasswordForm].forEach(form => form.classList.add('hidden'));
[loginTabBtn, signupTabBtn].forEach(btn => {
btn.classList.remove('border-blue-600', 'text-blue-600');
btn.classList.add('border-transparent', 'text-slate-500');
});
if (tabName === 'login') { loginForm.classList.remove('hidden'); loginTabBtn.classList.add('border-blue-600', 'text-blue-600'); }
else if (tabName === 'signup') { signupForm.classList.remove('hidden'); signupTabBtn.classList.add('border-blue-600', 'text-blue-600'); }
else if (tabName === 'forgotPassword') { forgotPasswordForm.classList.remove('hidden'); }
};

const showAuthMessage = (msg, type) => {
authMessage.textContent = msg;
authMessage.className = 'mt-4 p-3 rounded-lg text-sm text-center w-full';
if (type === 'error') authMessage.classList.add('bg-red-100', 'text-red-700');
else if (type === 'success') authMessage.classList.add('bg-green-100', 'text-green-700');
else authMessage.classList.add('bg-blue-100', 'text-blue-700');
authMessage.classList.remove('hidden');
};

loginTabBtn.addEventListener('click', () => showTab('login'));
signupTabBtn.addEventListener('click', () => showTab('signup'));
document.getElementById('switchToLogin').addEventListener('click', (e) => { e.preventDefault(); showTab('login'); });
document.getElementById('forgotPasswordLink').addEventListener('click', (e) => { e.preventDefault(); showTab('forgotPassword'); });
document.getElementById('returnToLogin').addEventListener('click', (e) => { e.preventDefault(); showTab('login'); });

const googleProvider = new GoogleAuthProvider();
const signInWithGoogle = async () => {
try {
showAuthMessage('Redirecting to Google...', 'info');
await signInWithPopup(auth, googleProvider);
} catch (error) { showAuthMessage(`Google sign-in failed: ${error.message}`, 'error'); }
};
document.getElementById('googleLoginBtn').addEventListener('click', signInWithGoogle);
document.getElementById('googleSignupBtn').addEventListener('click', signInWithGoogle);

loginForm.addEventListener('submit', async (e) => {
e.preventDefault();
const email = document.getElementById('loginEmail').value;
const password = document.getElementById('loginPassword').value;
try {
showAuthMessage('Logging in...', 'info');
await signInWithEmailAndPassword(auth, email, password);
} catch (error) { showAuthMessage(`Login failed: ${error.message}`, 'error'); }
});

signupForm.addEventListener('submit', async (e) => {
e.preventDefault();
const name = document.getElementById('signupName').value;
const email = document.getElementById('signupEmail').value;
const password = document.getElementById('signupPassword').value;
if (password.length < 6) { showAuthMessage('Password must be at least 6 characters.', 'error'); return; }
try {
showAuthMessage('Creating account...', 'info');
const userCredential = await createUserWithEmailAndPassword(auth, email, password);
await updateProfile(userCredential.user, { displayName: name });
} catch (error) { showAuthMessage(`Sign up failed: ${error.message}`, 'error'); }
});

forgotPasswordForm.addEventListener('submit', async (e) => {
e.preventDefault();
const email = document.getElementById('forgotEmail').value;
try {
showAuthMessage('Sending reset email...', 'info');
await sendPasswordResetEmail(auth, email);
showAuthMessage('Password reset email sent! Check your inbox.', 'success');
} catch (error) { showAuthMessage(`Failed to send email: ${error.message}`, 'error'); }
});

let currentActiveUserId = null;
const headerContainer = document.querySelector('header .container');
const logoTextContainer = document.querySelector('.logo-text-container-center');

const updateMobileHeaderLayout = (isLoggedIn) => {
if (window.innerWidth <= 767) {
if (isLoggedIn) {
headerContainer.classList.remove('justify-center');
headerContainer.classList.add('justify-between');
logoTextContainer.classList.remove('hidden');
logoTextContainer.classList.add('flex');
} else {
headerContainer.classList.remove('justify-between');
headerContainer.classList.add('justify-center');
logoTextContainer.classList.remove('hidden');
logoTextContainer.classList.add('flex');
}
} else {
headerContainer.classList.remove('justify-between', 'justify-center');
headerContainer.classList.add('flex', 'justify-between');
logoTextContainer.classList.remove('hidden');
logoTextContainer.classList.add('flex');
}
};

onAuthStateChanged(auth, (user) => {
const isLoggedIn = !!user && !user.isAnonymous;
if (isLoggedIn) {
document.getElementById('loginNavBtn').classList.add('hidden');
userMonogram.classList.remove('hidden');
const displayName = user.displayName;
const email = user.email;
let initials = displayName ? displayName.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2) : (email ? email.charAt(0).toUpperCase() : '');
userMonogram.textContent = initials;
closeModal(document.getElementById('loginModal'));
currentActiveUserId = user.uid;
currentChatId = getStoredChatSession()?.chatId || currentChatId;
console.log("Auth state changed: User logged in, UID:", currentActiveUserId);
if (chatWindow.classList.contains('is-visible')) {
ensureUserAuthenticatedForChat();
if (currentChatId) {
listenForMessages(currentChatId);
listenForChatSessionChanges(currentChatId);
}
}
} else {
document.getElementById('loginNavBtn').classList.remove('hidden');
userMonogram.classList.add('hidden');
authDropdown.classList.add('hidden');
currentActiveUserId = getOrCreateGuestId();
clearStoredChatSession();
currentChatId = null;
console.log("Auth state changed: User logged out/guest, ID:", currentActiveUserId);
if (chatWindow.classList.contains('is-visible')) {
ensureUserAuthenticatedForChat();
}
}
updateMobileHeaderLayout(isLoggedIn);
});

window.addEventListener('resize', () => {
updateMobileHeaderLayout(!!auth.currentUser);
});

userMonogram.addEventListener('click', (e) => { e.stopPropagation(); authDropdown.classList.toggle('hidden'); });
document.addEventListener('click', (e) => { if (!authStatusContainer.contains(e.target)) { authDropdown.classList.add('hidden'); } });
logoutBtn.addEventListener('click', () => {
clearStoredChatSession();
currentChatId = null;
signOut(auth);
});

const chatWindow = document.getElementById('chat-window');
const chatOpenBtn = document.getElementById('chat-open-btn');
const chatCloseBtn = document.getElementById('chat-close-btn');
const chatMinimizeBtn = document.getElementById('chat-minimize-btn');
const chatMessages = document.getElementById('chat-messages');
const chatInput = document.getElementById('chat-input');
const chatInputContainer = document.getElementById('chat-input-container');
const guestPromptContainer = document.getElementById('guest-prompt-container');
const guestLoginBtn = document.getElementById('guest-login-btn');
const unreadCounter = document.getElementById('unread-counter');
const typingIndicatorContainer = document.getElementById('typing-indicator-container');
const surveyContainer = document.getElementById('chat-survey-container');
const surveyForm = document.getElementById('chat-survey-form');
const starRatingContainer = document.getElementById('star-rating');
const friendlinessRating = document.getElementById('friendliness-rating');
const friendlinessValue = document.getElementById('friendliness-value');
const endChatConfirmModal = document.getElementById('end-chat-confirm-modal');
const endChatYesBtn = document.getElementById('end-chat-yes');
const endChatNoBtn = document.getElementById('end-chat-no');
const orderSelectionContainer = document.getElementById('order-selection-container');
const orderList = document.getElementById('order-list');
const closeOrderSelectionBtn = document.getElementById('close-order-selection-btn');
const sendMessageBtn = document.getElementById('send-message-btn');
const globalTooltip = document.getElementById('globalTooltip');

const CHAT_STORAGE_KEY = 'chatSessionState';

const storeChatSession = (chatId) => {
const user = auth.currentUser;
if (!user || user.isAnonymous || !chatId) return;
localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify({ chatId, uid: user.uid }));
};

const getStoredChatSession = () => {
const raw = localStorage.getItem(CHAT_STORAGE_KEY);
if (!raw) return null;
try {
const parsed = JSON.parse(raw);
const user = auth.currentUser;
if (!user || user.isAnonymous || parsed.uid !== user.uid) return null;
return parsed;
} catch (error) {
console.error('Failed to parse stored chat session', error);
return null;
}
};

const clearStoredChatSession = () => {
localStorage.removeItem(CHAT_STORAGE_KEY);
};

let currentChatId = getStoredChatSession()?.chatId || null;
let unsubscribeFromMessages = null;
let unsubscribeFromChatSession = null;
let isChatMinimized = true;
let unreadCount = 0;
let userTypingTimeout = null;
let initialWelcomeRendered = {};
let isFirstMessageSent = false;

const notificationSound = new Audio('https://cdn.freesound.org/previews/253/253887_3900531-lq.mp3');
notificationSound.volume = 0.5;

const ensureUserAuthenticatedForChat = () => {
const user = auth.currentUser;
const isAuthenticated = !!user && !user.isAnonymous;
if (!isAuthenticated) {
guestPromptContainer.classList.remove('hidden');
chatInputContainer.classList.add('hidden');
surveyContainer.classList.add('hidden');
orderSelectionContainer.classList.add('hidden');
} else {
guestPromptContainer.classList.add('hidden');
chatInputContainer.classList.remove('hidden');
}
return isAuthenticated;
};

const getOrCreateGuestId = () => {
let id = localStorage.getItem('guestChatId');
if (!id) {
id = `guest_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
localStorage.setItem('guestChatId', id);
}
return id;
};

const getOrCreateChatSession = async () => {
const user = auth.currentUser;
if (!user || user.isAnonymous) return null;

const storedSession = getStoredChatSession();
if (storedSession?.chatId) {
return storedSession.chatId;
}

const chatSessionData = {
createdAt: serverTimestamp(),
ownerUid: user.uid,
guestId: null,
status: 'active',
agentName: null,
isAgentTyping: false,
agentAskingForOrderId: false
};
const docRef = await addDoc(collection(db, "chats"), chatSessionData);
const chatId = docRef.id;
storeChatSession(chatId);
return chatId;
};

const renderMessage = (msg) => {
const messageDiv = document.createElement('div');
const user = auth.currentUser;
const isMyMessage = !!user && !user.isAnonymous && msg.sender === user.uid;

let classes = 'p-3 rounded-lg max-w-[85%] mb-2 break-words';
if (msg.type === 'system') {
classes = 'text-center text-sm text-slate-500 my-2';
messageDiv.innerHTML = `<span class="bg-white px-2 py-1 rounded-full">${msg.text}</span>`;
} else {
classes += isMyMessage ? ' bg-gray-200 text-slate-800 self-end' : ' bg-blue-100 text-blue-800 self-start';
messageDiv.textContent = msg.text;
}

messageDiv.className = classes;
if (msg.type === 'system' && msg.text.includes('has joined the chat.')) {
messageDiv.id = `agent-joined-${currentChatId}`;
}
chatMessages.appendChild(messageDiv);
chatMessages.scrollTop = chatMessages.scrollHeight;
};

const listenForChatSessionChanges = (chatId) => {
if (unsubscribeFromChatSession) unsubscribeFromChatSession();
unsubscribeFromChatSession = onSnapshot(doc(db, "chats", chatId), async (docSnap) => {
const data = docSnap.data();
if (!data) return;

const agentJoinedFlag = localStorage.getItem(`agentJoined_${chatId}`);
if (data.agentName && data.agentHasJoined && !agentJoinedFlag) {
const joinMsgText = `<i class="fa-solid fa-headset mr-2"></i>${data.agentName} has joined the chat.`;
await addDoc(collection(db, `chats/${chatId}/messages`), {
text: joinMsgText,
timestamp: serverTimestamp(),
sender: 'system',
type: 'system'
});
localStorage.setItem(`agentJoined_${chatId}`, 'true');
}

typingIndicatorContainer.style.display = data.isAgentTyping ? 'block' : 'none';
if (data.isAgentTyping) chatMessages.scrollTop = chatMessages.scrollHeight;
if (data.status === 'ended_by_agent') {
chatInputContainer.classList.add('hidden');
guestPromptContainer.classList.add('hidden');
surveyContainer.classList.remove('hidden');
orderSelectionContainer.classList.add('hidden');
clearStoredChatSession();
localStorage.removeItem(`agentJoined_${chatId}`);
}
if (data.agentAskingForOrderId) {
displayOrderSelectionUI();
} else {
orderSelectionContainer.classList.add('hidden');
}
});
};

const listenForMessages = (chatId) => {
if (unsubscribeFromMessages) unsubscribeFromMessages();
currentChatId = chatId;
const messagesRef = collection(db, `chats/${chatId}/messages`);
const q = query(messagesRef, orderBy("timestamp"));
unsubscribeFromMessages = onSnapshot(q, (snapshot) => {
chatMessages.innerHTML = '';
if (!initialWelcomeRendered[chatId] && snapshot.empty) {
const user = auth.currentUser;
const userName = user?.displayName?.split(' ')[0] || 'there';
renderMessage({ type: 'system', text: `Hi ${userName}, how can we help you today?` });
initialWelcomeRendered[chatId] = true;
}

snapshot.forEach(doc => {
const msgData = doc.data();
renderMessage(msgData);
const user = auth.currentUser;
const isMyMessage = !!user && !user.isAnonymous && msgData.sender === user.uid;
if (!isMyMessage && isChatMinimized) {
unreadCount++;
unreadCounter.textContent = unreadCount;
unreadCounter.classList.add('visible');
notificationSound.play().catch(e => console.log("Audio play failed:", e));
}
});
});
};

const resetChatUI = () => {
endChatConfirmModal.classList.add('hidden');
endChatConfirmModal.classList.remove('flex');
surveyContainer.classList.add('hidden');
guestPromptContainer.classList.add('hidden');
chatInputContainer.classList.remove('hidden');
orderSelectionContainer.classList.add('hidden');
typingIndicatorContainer.style.display = 'none';
chatMessages.innerHTML = '';
initialWelcomeRendered = {};
};

const openChat = async () => {
resetChatUI();
chatWindow.classList.add('is-visible');
isChatMinimized = false;
unreadCount = 0;
unreadCounter.classList.remove('visible');

if (!ensureUserAuthenticatedForChat()) {
currentChatId = null;
return;
}

if (!currentChatId) {
currentChatId = await getOrCreateChatSession();
isFirstMessageSent = false;
}

if (currentChatId) {
listenForMessages(currentChatId);
listenForChatSessionChanges(currentChatId);
}
};
chatOpenBtn.addEventListener('click', openChat);

const minimizeChat = () => {
chatWindow.classList.remove('is-visible');
isChatMinimized = true;
};
chatMinimizeBtn.addEventListener('click', minimizeChat);

chatCloseBtn.addEventListener('click', () => {
endChatConfirmModal.classList.add('flex');
endChatConfirmModal.classList.remove('hidden');
});

endChatNoBtn.addEventListener('click', () => {
endChatConfirmModal.classList.add('hidden');
endChatConfirmModal.classList.remove('flex');
});

endChatYesBtn.addEventListener('click', async () => {
if (currentChatId) {
await addDoc(collection(db, `chats/${currentChatId}/messages`), {
text: "Chat ended by user.",
timestamp: serverTimestamp(),
sender: 'system',
type: 'system'
});
await updateDoc(doc(db, "chats", currentChatId), { status: 'ended_by_user' });
}
clearStoredChatSession();
localStorage.removeItem(`agentJoined_${currentChatId}`);
currentChatId = null;
chatMessages.innerHTML = '';
endChatConfirmModal.classList.add('hidden');
endChatConfirmModal.classList.remove('flex');
minimizeChat();
});

const sendMessage = async (text) => {
if (text.trim() === '') return;

if (!ensureUserAuthenticatedForChat()) return;

if (!currentChatId) {
currentChatId = await getOrCreateChatSession();
isFirstMessageSent = false;
if (!currentChatId) return;
}

const user = auth.currentUser;
if (!user || user.isAnonymous) return;

if (!isFirstMessageSent) {
isFirstMessageSent = true;
try {
const cloudFunctionUrl = 'https://us-central1-buyback-a0f05.cloudfunctions.net/api/email-support';
const userEmail = user.email || 'Member';
const userName = user.displayName || userEmail;
const firstMessage = text;

await fetch(cloudFunctionUrl, {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({
chatId: currentChatId,
userName: userName,
userEmail: userEmail,
firstMessage: firstMessage
})
});
console.log('Support email sent for new chat session.');
} catch (error) {
console.error("Error sending support email:", error);
}
}

const messageData = { text, timestamp: serverTimestamp(), sender: user.uid };
await addDoc(collection(db, `chats/${currentChatId}/messages`), messageData);
chatInput.value = '';
await updateDoc(doc(db, "chats", currentChatId), {
userTypingText: '',
lastMessage: `User: ${text}`,
lastMessageTimestamp: serverTimestamp()
});
};

chatInput.addEventListener('keypress', (e) => {
if (e.key === 'Enter') {
e.preventDefault();
sendMessage(chatInput.value);
}
});
sendMessageBtn.addEventListener('click', () => {
sendMessage(chatInput.value);
});

chatInput.addEventListener('keyup', () => {
clearTimeout(userTypingTimeout);
userTypingTimeout = setTimeout(async () => {
const user = auth.currentUser;
if (currentChatId && user && !user.isAnonymous) {
await updateDoc(doc(db, "chats", currentChatId), { userTypingText: chatInput.value });
}
}, 300);
});

guestLoginBtn.addEventListener('click', () => openModal('loginModal'));

friendlinessRating.addEventListener('input', (e) => { friendlinessValue.textContent = e.target.value; });
starRatingContainer.addEventListener('mouseover', e => {
if (e.target.tagName === 'I') {
const rating = e.target.dataset.value;
Array.from(starRatingContainer.children).forEach(star => star.classList.toggle('selected', star.dataset.value <= rating));
}
});
starRatingContainer.addEventListener('mouseout', () => {
const currentRating = starRatingContainer.dataset.rating;
Array.from(starRatingContainer.children).forEach(star => star.classList.toggle('selected', star.dataset.value <= currentRating));
});
starRatingContainer.addEventListener('click', e => {
if (e.target.tagName === 'I') {
starRatingContainer.dataset.rating = e.target.dataset.value;
}
});

surveyForm.addEventListener('submit', async (e) => {
e.preventDefault();
const surveyData = {
overallRating: parseInt(starRatingContainer.dataset.rating, 10),
friendliness: friendlinessRating.value,
resolved: document.querySelector('input[name="issue-resolved"]:checked')?.value || null,
comments: document.getElementById('survey-comments').value
};
await setDoc(doc(db, `chats/${currentChatId}/survey/feedback`), { ...surveyData, submittedAt: serverTimestamp() });
try {
const cloudFunctionUrl = 'https://us-central1-buyback-a0f05.cloudfunctions.net/api/submit-chat-feedback';
const response = await fetch(cloudFunctionUrl, {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ chatId: currentChatId, surveyData: surveyData })
});
if (!response.ok) throw new Error(`Server responded with status: ${response.status}`);
console.log('Feedback email sent successfully:', await response.json());
} catch (error) { console.error("Error sending feedback email:", error); }
surveyContainer.innerHTML = '<p class="text-center font-semibold text-green-600">Thank you for your feedback!</p>';
});

const fetchUserOrders = async () => {
return new Promise((resolve) => {
const unsubscribe = onAuthStateChanged(auth, async (user) => {
unsubscribe();
if (!user || user.isAnonymous) {
console.log("fetchUserOrders: User not logged in, returning requiresLogin: true");
resolve({ requiresLogin: true });
return;
}
const userId = user.uid;
console.log("fetchUserOrders: Current user ID:", userId);
const ordersRef = collection(db, `users/${userId}/orders`);
const q = query(ordersRef, orderBy("timestamp", "desc"));
try {
await createDummyOrder(userId);
const snapshot = await getDocs(q);
console.log("fetchUserOrders: Orders snapshot size:", snapshot.size);
if (snapshot.empty) {
console.log("fetchUserOrders: No orders found for this user in Firestore path:", `users/${userId}/orders`);
}
const orders = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
console.log("fetchUserOrders: Fetched orders:", orders);
resolve(orders);
} catch (error) {
console.error("fetchUserOrders: Error fetching user orders:", error);
resolve({ error: error.message });
}
});
});
};

const createDummyOrder = async (userId) => {
const ordersRef = collection(db, `users/${userId}/orders`);
const existingOrders = await getDocs(ordersRef);
if (existingOrders.empty) {
console.log("Creating initial dummy orders for user:", userId);
let lastOrderNum = parseInt(localStorage.getItem('lastOrderNum') || '0', 10);
const generateSequentialOrderId = () => {
lastOrderNum++;
localStorage.setItem('lastOrderNum', lastOrderNum);
return `SHC-${String(lastOrderNum).padStart(5, '0')}`;
};
await setDoc(doc(db, `users/${userId}/orders`, generateSequentialOrderId()), {
orderId: `SHC-${String(lastOrderNum).padStart(5, '0')}`,
deviceName: 'iPhone 15 Pro Max',
storage: '256GB',
price: 700,
reoffer: null,
imageUrl: 'https://raw.githubusercontent.com/ToratYosef/BuyBacking/refs/heads/main/iphone/assets/i15pm.webp',
timestamp: serverTimestamp()
});
await setDoc(doc(db, `users/${userId}/orders`, generateSequentialOrderId()), {
orderId: `SHC-${String(lastOrderNum).padStart(5, '0')}`,
deviceName: 'Samsung Galaxy S24 Ultra',
storage: '512GB',
price: 600,
reoffer: 550,
imageUrl: 'https://raw.githubusercontent.com/ToratYosef/BuyBacking/refs/heads/main/samsung/assets/s24u.webp',
timestamp: serverTimestamp()
});
await setDoc(doc(db, `users/${userId}/orders`, generateSequentialOrderId()), {
orderId: `SHC-${String(lastOrderNum).padStart(5, '0')}`,
deviceName: 'iPad Pro (M2)',
storage: '128GB',
price: 550,
reoffer: null,
imageUrl: 'https://raw.githubusercontent.com/ToratYosef/BuyBacking/refs/heads/main/assets/ipm2.webp',
timestamp: serverTimestamp()
});
} else {
console.log("Example orders already exist for user:", userId);
}
};

const parseCurrencyValue = (value) => {
const numeric = Number(value);
return Number.isFinite(numeric) ? numeric : null;
};

const getDisplayPrice = (order) => {
if (!order || typeof order !== 'object') {
return 0;
}
const candidates = [
order.reoffer,
order.reOffer?.newPrice,
order.reOffer,
order.price,
order.estimatedQuote,
];

for (const candidate of candidates) {
const numeric = parseCurrencyValue(candidate);
if (numeric !== null) {
return numeric;
}
}

return 0;
};

const renderOrderSelection = (orders) => {
orderList.innerHTML = '';
if (orders.requiresLogin) {
orderList.innerHTML = '<p class="text-center text-slate-500">Please <a href="#" id="orderLoginPromptLink" class="text-blue-600 font-semibold hover:underline">log in</a> to view and select your orders.</p>';
document.getElementById('orderLoginPromptLink').addEventListener('click', (e) => {
e.preventDefault();
openModal('loginModal');
orderSelectionContainer.classList.add('hidden');
});
orderSelectionPrompt.textContent = 'Login to access your orders:';
return;
}

if (orders.length === 0) {
orderList.innerHTML = '<p class="text-center text-slate-500">No recent orders found.</p>';
orderSelectionPrompt.textContent = 'Please select your order:';
return;
}
orderSelectionPrompt.textContent = 'Please select your order:';
orders.forEach(order => {
const orderCard = document.createElement('div');
orderCard.className = 'order-card';
orderCard.dataset.orderId = order.orderId;
const reofferAmount = parseCurrencyValue(order.reoffer ?? order.reOffer?.newPrice);
const displayPriceValue = getDisplayPrice(order);
const formattedPrice = displayPriceValue.toFixed(2);
orderCard.innerHTML = `
<img src="${order.imageUrl || 'https://placehold.co/48x48/e0e7ff/4338ca?text= '}" alt="${order.deviceName}" onerror="this.onerror=null;this.src='https://placehold.co/48x48/e0e7ff/4338ca?text= ';">
<div class="order-card-details">
<strong>ID: ${order.orderId} - ${order.deviceName}</strong>
<span>${order.storage} | $${formattedPrice}</span>
${reofferAmount !== null ? `<span class="reoffer">Reoffer: $${reofferAmount.toFixed(2)}</span>` : ''}
</div>
`;
orderCard.addEventListener('click', () => handleOrderSelection(order));
orderList.appendChild(orderCard);
});
};

const displayOrderSelectionUI = async () => {
guestPromptContainer.classList.add('hidden');
orderSelectionContainer.classList.remove('hidden');
orderList.innerHTML = '<p class="text-center text-blue-500">Loading your orders...</p>';
const orders = await fetchUserOrders();
renderOrderSelection(orders);
};

const handleOrderSelection = async (order) => {
const reofferAmount = parseCurrencyValue(order.reoffer ?? order.reOffer?.newPrice);
const displayPriceValue = getDisplayPrice(order);
const formattedPrice = displayPriceValue.toFixed(2);
const messageText = `Selected Order: ID: ${order.orderId}, Device: ${order.deviceName}, Storage: ${order.storage}, Price: $${formattedPrice}${reofferAmount !== null ? `, Reoffer: $${reofferAmount.toFixed(2)}` : ''}`;
await sendMessage(messageText);
orderSelectionContainer.classList.add('hidden');
if (currentChatId) {
await updateDoc(doc(db, "chats", currentChatId), { agentAskingForOrderId: false });
}
};

closeOrderSelectionBtn.addEventListener('click', async () => {
orderSelectionContainer.classList.add('hidden');
if (currentChatId) {
await updateDoc(doc(db, "chats", currentChatId), { agentAskingForOrderId: false });
}
});

const chatOrderBtn = document.getElementById('chat-order-btn');
chatOrderBtn.addEventListener('click', async () => {
if (currentChatId) {
await updateDoc(doc(db, "chats", currentChatId), { agentAskingForOrderId: true });
} else {
displayOrderSelectionUI();
}
});

const chatHeaderButtons = document.querySelectorAll('.chat-header-button');

chatHeaderButtons.forEach(button => {
let tooltipTimeout;

button.addEventListener('mouseover', (e) => {
clearTimeout(tooltipTimeout);
const tooltipText = button.dataset.tooltipText;
if (tooltipText) {
globalTooltip.textContent = tooltipText;
globalTooltip.style.visibility = 'visible';
globalTooltip.style.opacity = '1';

const rect = button.getBoundingClientRect();
globalTooltip.style.top = `${rect.bottom + 8}px`;
globalTooltip.style.left = `${rect.left + rect.width / 2}px`;
globalTooltip.style.transform = `translateX(-50%)`;
}
});

button.addEventListener('mouseout', () => {
tooltipTimeout = setTimeout(() => {
globalTooltip.style.visibility = 'hidden';
globalTooltip.style.opacity = '0';
}, 100);
});

button.addEventListener('mouseenter', () => {
clearTimeout(tooltipTimeout);
});
});

// NEW: Intersection Observer for scroll-triggered animations
const observerOptions = {
root: null,
rootMargin: '0px',
threshold: 0.1
};
const observer = new IntersectionObserver((entries, observer) => {
entries.forEach(entry => {
if (entry.isIntersecting) {
entry.target.classList.add('animate-fadeInUp');
observer.unobserve(entry.target);
}
});
}, observerOptions);

document.querySelectorAll('.animate-on-scroll').forEach(el => {
el.style.opacity = '0';
el.style.transform = 'translateY(20px)';
observer.observe(el);
});
});
